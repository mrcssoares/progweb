<?php
/**
 * Created by PhpStorm.
 * User: marcos
 * Date: 10/09/16
 * Time: 16:22
 */
$senha = "123";
$senhaCriptografada = md5($senha);
echo $senhaCriptografada;


?>